﻿Func<int[], int[]> add = numbers => {
    for(int i = 0; i < numbers.Length;i++)
    {
        numbers[i] += 1;
    }
    return numbers;
};
Func<int[], int[]> subtract = numbers => {
    for(int i = 0; i < numbers.Length;i++)
    {
        numbers[i] -= 1;
    }
    return numbers;
};
Func<int[], int[]> multiply = numbers => {
    for(int i = 0; i < numbers.Length;i++)
    {
        numbers[i] *= 2;
    }
    return numbers;
};
Func<int[], int[]> print = numbers => {
    string output = "";
    for (int i = 0; i < numbers.Length; i++)
    {
        output += $"{numbers[i]} ";
    }
    Console.WriteLine(output);
    return numbers;
};
void Operations(string message)
{
    string operation = Console.ReadLine();
    var range = message.Split(" ").Select(n => Convert.ToInt32(n)).ToArray();
    while (operation != "end")
    {
        if (operation == "add")
        {
            add(range);
        }
        else if (operation == "multiply")
        {
            multiply(range);
        }
        else if (operation == "subtract")
        {
            subtract(range);
        }
        else if (operation == "print")
        {
            print(range);
        }
        operation = Console.ReadLine();
    }
}
Operations(Console.ReadLine());