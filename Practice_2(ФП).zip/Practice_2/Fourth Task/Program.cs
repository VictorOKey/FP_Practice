﻿void Comparer(string message)
{
    var array = message.Split(" ").Select(n => Convert.ToInt32(n)).ToArray();
    int Comparer(int a, int b)
    {
        if (a % 2 != 0)
        {
            if (b % 2 == 0)
            {
                return 0;
            }
            else
            {
                return a.CompareTo(b);
            }
        }
        else
        {
            if (b % 2 == 0)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
    }

    Array.Sort(array, Comparer);
    string str = "";
    for (int i = 0; i < array.Length; i++)
    {
        str += $"{array[i]} ";;
    }
    Console.WriteLine(str);
}
Comparer(Console.ReadLine());