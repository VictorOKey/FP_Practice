﻿void NameFilter(int count, string message)
{
    string[] str = message.Split(" ").Select(n => n).Where(n => n.Length <= count).ToArray();
    Console.WriteLine(String.Join(" ", str));
}
NameFilter(Convert.ToInt32(Console.ReadLine()), Console.ReadLine());