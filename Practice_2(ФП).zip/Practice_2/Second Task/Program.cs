﻿Func<int[], string> div = numbers =>
{
    string output = "";
    int a = Convert.ToInt32(Console.ReadLine());
    for(int i = 0; i < numbers.Length;i++)
    {
        if (numbers[i] % a != 0)
        {
            output+= $"{numbers[i]} ";
        }
    }
    return output;
};
void Reverse(string message)
{
    var range = message.Split(" ").Select(n => Convert.ToInt32(n)).Reverse().ToArray();
    Console.WriteLine(div(range));
}
Reverse(Console.ReadLine());