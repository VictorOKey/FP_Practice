﻿Func<int[], string> odd = message =>
{
    string str = "";
    for (int i = message[0]; i <= message[1]; i++)
    {
        if (i % 2 != 0)
        {
            str += $"{i} ";
        }
    }
    return str;
};
Func<int[], string> even = message =>
{
    string str = "";
    for (int i = message[0]; i <= message[1]; i++)
    {
        if (i % 2 == 0)
        { 
            str += $"{i} ";    
        }
    }
    return str;
};
void Defining(string mes, string area)
{
    var message = mes.Split(" ").Select(n => Convert.ToInt32(n)).ToArray();
    if (area == "odd")
    {
        Console.WriteLine(odd(message));
    }
    else if (area == "even")
    {
        Console.WriteLine(even(message));
    }
}
Defining(Console.ReadLine(),Console.ReadLine());