﻿Func<string, int> mes = message =>
{
    int min = message.Split(" ").Select(n => int.Parse(n))
        .ToArray().Min();
    return min;
};
Console.WriteLine(mes(Console.ReadLine()));