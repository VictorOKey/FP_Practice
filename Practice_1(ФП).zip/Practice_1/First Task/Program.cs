﻿Action<string> mes = message =>
{
    foreach (string str in message.Split(" ").Select(n => n)
                 .ToArray())
    {
        Console.WriteLine(str);
    }
};
mes(Console.ReadLine());