﻿Action<string> mes = message =>
{
    foreach (string str in message.Split(" ").Select(n => n)
                 .ToArray())
    {
        Console.WriteLine($"{str} (Нет в наличии)");
    }
};
mes(Console.ReadLine());